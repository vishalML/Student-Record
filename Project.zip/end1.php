<html>
  <head>
  <meta name="viewport" value="width=device-width ,initial-scale=1.0">
  <style>
    .b1 {

              border: none;
              margin: 25px 50px 75px 300px;
              opacity: 0.8;
              border-radius: 12px;
              color: white;
              padding: 15px 20px;
              text-align: center;
              font-size: 24px;
              cursor: pointer;
              box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
              width: 200px;
            }
    .b1:hover {opacity: 1}
    a:link{
      text-decoration: none;
    }
    a:visited{
      color: white;
      background-color: transparent;
    }

  </style>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="style2.css">

    <title>Welcome!</title>
  </head>

  <body bgcolor=safroon>
  
  <div id="image">
	<image src="IMG-20180602-WA0010.jpg" width="150px" height="100px">
	</div>
	<image src="IMG-20180602-WA0011.jpg" >

    <h1><b>Thankyou for joining with us</b></h1>

    <p style="border: 2px solid black;border-radius: 25px; padding: 30px; margin: 100px 50px 75px 100px;">
      <a href="index.php">
      <button class="b1" style="background-color: green;"  title="Home" >
        Home
      </button></a>
      <a href="login.php">
      <button class="b1" style="background-color: blue;" title="Login">
        Login
      </button></a>
      
      <button class="b1" style="background-color: tomato;" title="Exit">
        Exit
      </button>

    </p>

  </body>
</html>
