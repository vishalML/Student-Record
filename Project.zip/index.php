
<html>
  <head>
  <meta name="viewport" value="width=device-width ,initial-scale=1.0">
  <style>
  
    .b1 {

              border: none;
              margin: 25px 50px 75px 300px;
              opacity: 0.8;
              border-radius: 12px;
              color: white;
              padding: 15px 20px;
              text-align: center;
              font-size: 24px;
              cursor: pointer;
              box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
              width: 200px;
            }
    .b1:hover {opacity: 1}
    a:link{
      text-decoration: none;
    }
    a:visited{
      color: white;
      background-color: transparent;
    }

  </style>
  
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="style2.css">
  

    <title>Welcome</title>
  </head>

  <body>

    <h1><b>Welcome to East Coast Railway</b></h1>
	
	<div id="image">
	<image src="IMG-20180602-WA0010.jpg" width="150px" height="100px">
	</div>
	<image src="IMG-20180602-WA0011.jpg" >

    <p style="border: 2px solid black;border-radius: 15px; padding: 20px; margin: 80px 30px 55px 80px;">
      <a href="Register.php";>
      <button class="b1" style="background-color: green;"  title="New User" >
        New User
      </button></a>
      <a href="login.php";>
      <button class="b1" style="background-color: blue;" title="Existing User">
        Existing User
      </button></a>
     </br> <a href="History.html";>
        <button class="b1" style="background-color: darkorange;" title="History">
        History
      </button></a>
      <a href="contact.html";>
      <button class="b1" style="background-color: tomato;" title="Contact Us">
        Contact Us
      </button>
 <a href="Admin.php";>
      <button class="b1" style="background-color: tomato;" title="Contact Us">
        GET Report
      </button>
   </p>

  </body>
</html>
<?php
?>
