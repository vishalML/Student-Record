<!DOCTYPE html>

<html>
<head>
<title>Login</title>
<meta name="viewport" value="width=device-width ,initial-scale=1.0">
 <link rel="stylesheet" href="style.css">
 <link rel="stylesheet" href="style2.css">

</head>

<body align="center" bgcolor=peach>
<div id="image">
	<image src="IMG-20180602-WA0010.jpg" width="150px" height="100px">
	</div>
	<image src="IMG-20180602-WA0011.jpg" >



<h1 class="title">LOGIN PAGE</h1>
<form action="login.php" method="post">
<label for="emailid" ><b>Registered Email</label>
</b>							
<br>								
<input type="text" class="form-control" name="email" id="name"  placeholder="Enter your Emailid" required />
<br>								
<br>													
<label for="password"><b>Password</label>
</b>							
<br>									
<input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password" required />
	<br>							
<br>	

<input type="submit" class="b2 " name="login" value="login" >
</form>
      
<p class="message">Not registered yet? </p>
<a href="Register.php">Create an account</a>
</br></br>
<a href="Reset.php">Forget password</a>
<a href="Admin.php"><div class="biod">GET YOUR Report</div></a>

</body>
</html>

<?php

include('dbcon.php');

 if(isset($_POST['login']))
 {
  $email= $_POST['emailid'];
  $password= $_POST['password'];
  
 $qury="SELECT * FROM `user_login` WHERE `email`='$email' AND `password`='$password'";

 $result=mysqli_query($con,$qury);
  $row=mysqli_num_rows($result);
  if($row<1)
  {
	  ?>
	  <script> alert('username or password does not match');
	  window.open('login.php','self');
	  </script>
	  <?php
  }
  else{
	  ?>
	  <script>
	     alert('You Have Successufully Login');
	  </script>
	  <?php
	   if(isset($_POST['login']))
	   {	
         $email= $_POST['emailid'];
     $query1= "SELECT `name` FROM `user_login` WHERE `email`='$email'";
	 $result1=mysqli_query($con,$query1);
	  $row=mysqli_fetch_array($result1);
	  $mail2=$row['name'];
	  $date2= date("Y-n-d");
	  
	  $query2="INSERT INTO `attendence`(`name`,`email`,`dtime`) VALUES ('$mail2','$email','$date2')";
	  $result2 = mysqli_query($con,$query2);
	   }
	   ?>
	   <script>
	    window.open('end1.php');
	   </script>
	   <?php
  }



 }

?>