<?php
  
  
  
  $con=mysqli_connect("localhost","root","","register");
  if($con==false)
  {
	  echo "connection is not establish";
  }
  
  ?>