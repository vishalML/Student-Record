<!doctype html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="style2.css">

</head>
<body>

 <h1> Welcome to East cost Railways</h1>
 <div id="image">
	<image src="IMG-20180602-WA0010.jpg" width="150px" height="100px">
	</div>
	<image src="IMG-20180602-WA0011.jpg" >
 
 
<form action="Admin.php" method="post">
<label for="name"><b>Registered email </label>
 <input type="text" name="name" id="name" placeholder="Emailid of Candidate" required>
 </br></br>
 <label for="idate"><b>Initail Date</label>
 <input type="text" name="idate" id="name" placeholder="yyyy-m-dd"required>
</br></br>
<label for="fdate"><b> Final Date </label>

 <input type="text" name="fdate" id="name" placeholder="yyyy-m-dd"required>
  
  </br></br>
  
  <input type="submit" name="submit" value="GET Report" class="b2">
   
    </form>

<table width="400px"  border="1" cellpadding="1" cellspacing="1">
<tr>
<th>Name</th>
<th> Date in which present</th>
</tr>
















<?php
  include('dbcon.php');
  
   if(isset($_POST['submit']))
   {
	   $email= $_POST['name'];
       $indate= $_POST['idate'];
	   $fadate= $_POST['fdate'];
	   
       $query = "SELECT * FROM `attendence` WHERE `email`='$email' AND dtime BETWEEN '$indate'AND '$fadate' ";
 
	 
         $result=mysqli_query($con,$query);
		 $row=mysqli_num_rows($result);
	      if($row<1)
  {
	  ?>
	  <script> alert('please enter valid username ,Initial Date and Final Date');
	  window.open('Admin.php','self');
	  </script>
	  <?php
  }
	 else{
		  while($ab=mysqli_fetch_assoc($result))
		  {
              echo "<tr>";
			  echo "<td>".$ab['name']."</td>";
			  echo "<td>".$ab['dtime']."</td>";
			  echo "</tr>";
			 
			   
		  }
  
	 }
  
  
  
  
  
	 }
  
  
  
  ?>
  </table>
  </body>
  </html>
  