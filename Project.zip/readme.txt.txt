1. create database register
2.create table "user_login"
  1.create row id,name,email,password,confirm_password

3.create table "bio_data"
 1.create row id,name,Father Name,Postal Aderss,Personal Address,sex,City,Course,
   District,State,PinCode,EmailId,DOB,MobileNo.

4.create table attendence
   1. create row name,email,dtime.
      dtime must be date type

   thank you!!!