<!DOCTYPE html>

<html>
<head>
<title>Reset Password</title>
<meta name="viewport" value="width=device-width ,initial-scale=1.0">
 <link rel="stylesheet" href="style.css">
 <link rel="stylesheet" href="style2.css">

</head>

<body align="center" bgcolor=peach>

<div id="image">
	<image src="IMG-20180602-WA0010.jpg" width="150px" height="100px">
	</div>
	<image src="IMG-20180602-WA0011.jpg" >



<h1 class="title">Reset page</h1>
<form action="Reset.php" method="post">
<label for="username" ><b>Username</label>
</b>							
<br>								
<input type="text" class="form-control" name="username" id="name"  placeholder="Enter your Username" required />
								
													

								
<br>	
<label for="dob"><b> Enter Date of Birth</label>
</b>							
<br>									
<input type="text" class="form-control" name="dob" id="email"  placeholder="dd/mm/yy/" required />
	<br>	
							

<label for="mnumber"><b> Enter mobile number</label>
</b>							
<br>									
<input type="text" class="form-control" name="mnumber" id="email"  placeholder="Mobile number" required />
	<br>	



<input type="submit" class="b2" name="login" value="Password" >
</form>
      
<p class="message">Not registered yet?</p>
<a href="Register.php">create an account</a>


</body>
</html>

<?php

include('dbcon.php');

 if(isset($_POST['login']))
 {
  $usrname = $_POST['username'];
  $dateb = $_POST['dob'];
  $mobn = $_POST['mnumber'];
  
  
  
 $qury= "SELECT * FROM `bio_data` WHERE `EmailId`='$usrname' AND `DOB`='$dateb' AND `MobileNo`='$mobn'";

 $result=mysqli_query($con,$qury);
  $row=mysqli_num_rows($result);
  if($row<1)
  {
	  ?>
	  <script> alert('username or mobileno, DOB  does not match');
	  window.open('Reset.php','self');
	  </script>
	  <?php
  }
  else{
	  $qury= "SELECT `password` FROM `user_login` WHERE `email`='$usrname'";
	  $result=mysqli_query($con,$qury);
	  $row=mysqli_fetch_array($result);
	  echo '<h2>Your Password :</h2>';
	  echo $row['password'];
	  
	  
  }


 }

?>