<html>
<head>
<meta name="viewport" value="width=device-width ,initial-scale=1.0">
 <link rel="stylesheet" href="style.css">
 <link rel="stylesheet" href="style2.css">
</head>
<body bgcolor=grey>

<div id="image">
	<image src="IMG-20180602-WA0010.jpg" width="150px" height="100px">
	</div>
	<image src="IMG-20180602-WA0011.jpg" >


<form action="biodata.php" method="post">
<table cellpadding="2" width="20%" bgcolor="lightgreen" align="center"
cellspacing="2">

<tr>
<td colspan=2>
<center><font size=4><b>BIO-DATA Form</b></font></center>
</td>
</tr>

<tr>

<td>Name</td>
<td><input type=text name="name" id="name" size="30" required ></td>
</tr>

<tr>
<td>Father Name</td>
<td><input type="text" name="fathername" id="name" 
size="30" required ></td>
</tr>
<tr>
<td>Postal Address</td>
<td><input type="text" name="paddress" id="address" size="30" required ></td>
</tr>

<tr>
<td>Personal Address</td>
<td><input type="text" name="personaladdress"
id="address" size="30" required ></td>
</tr>

<tr>
<td>Sex</td>
<td><input type="radio" name="sex" value="male" size="10">Male
<input type="radio" name="sex" value="Female" size="10">Female</td>
</tr>

<tr>
<td>City</td>
<td><input type="text" name="city" id="city"
size="30" required ></td>
</tr>

<tr>
<td>Course</td>
<td><select name="Course" id="District" required >
<option value="-1" selected>select..</option>
<option value="B.Tech">B.TECH</option>
<option value="MCA">MCA</option>
<option value="MBA">MBA</option>
<option value="BCA">BCA</option>
</select></td>
</tr>

<tr>
<td>District</td>
<td><input type="text" name="District" id="District"
size="30" required ></td>

</tr>

<tr>
<td>State</td>
<td><input type="text" name="State" id="District"
size="30" required ></td>
</tr>
<tr>
<td>PinCode</td>
<td><input type="text" name="pincode" id="District" size="30" required ></td>

</tr>
<tr>
<td>EmailId</td>
<td><input type="text" name="emailid" id="email" size="30" required ></td>
</tr>

<tr>
<td>DOB</td>
<td><input type="text" name="dob" id="District" size="10" placeholder= "yyyy/mm/dd" required ></td>
</tr>

<tr>
<td>MobileNo</td>
<td><input type="text" name="mobileno" id="District" size="30" required ></td>
</tr>

<tr>
<td>Branch</td>
<td><input type="text" name="branch"
id="name" size="30" required ></td>
</tr>

<tr>
<td>Semester</td>
<td><input type="text" name="semester"
id="name" size="30" required ></td>
</tr>

<tr>
<td>College Name</td>
<td><input type="text" name="collegename"
id="name" size="30" required ></td>
</tr>

<tr>
<td><input type="reset"></td>
<td colspan="2"><input type="submit" value="Submit Form" name="submit" class="b2" /></td>
</tr>
</table>
</form>
</body>
</html>

<?php

include('dbcon.php');

if(isset($_POST['submit']))
{
	$nam = $_POST['name'];
	
	$fathrnam = $_POST['fathername'];
	$postaladdrs = $_POST['paddress'];
	$prsnladres = $_POST['personaladdress'];
	$sex = $_POST['sex'];
	$cty = $_POST['city'];
	$cours = $_POST['Course'];
	$district = $_POST['District'];
	$stat = $_POST['State'];
	$pincod = $_POST['pincode'];
	$mail = $_POST['emailid'];
	$dbirth = $_POST['dob'];
	$mnumber = $_POST['mobileno'];
	$branch = $_POST['branch'];
	$sem = $_POST['semester'];
        $clg =$_POST['collegename'];
	
	$query = "SELECT * FROM `user_login` WHERE `name`='$nam' AND `email`='$mail'";
	$result1=mysqli_query($con,$query);
	
	if($result1 == true){
		
	
	
$qury="INSERT INTO `bio_data`( `name`, `Father Name`, `Postal address`, `Personal address`, `Sex`, `City`, `District`, `State`, `Pincode`, `EmailId`, `DOB`, `Mobile No', `Course`, 'Branch', 'Semester', 'College Name') VALUES 
('$nam','$fathrnam','$postaladdrs','$prsnladres','$sex','$cty','$cours','$district','$stat','$pincod','$mail','$dbirth','$mnumber','$branch','$sem','$clg')";

$result=mysqli_query($con,$qury);

if($result == true)
{
	?>
	<script>
	window.open('end1.php');
	</script>
	<?php
}
	}
	else{
		?>
		<script>
		   alert('Go And Register Yourself First');
		   window.open('Register.php');
		
		</script>
		<?php
		
	}
}




?>



