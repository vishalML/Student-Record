<!DOCTYPE html>

<head>
<title>Register</title>
<meta name="viewport" value="width=device-width ,initial-scale=1.0">
 <link rel="stylesheet" href="style.css">
 <link rel="stylesheet" href="style2.css">

</head>

<body align="center" bgcolor=lightpink>
<div id="image">
	<image src="IMG-20180602-WA0010.jpg" width="150px" height="100px">
	</div>
	<image src="IMG-20180602-WA0011.jpg" >



<h2 class="title">REGISTER YOURSELF</h2>
<form action="Register.php" method="post">
<label for="name" ><b>Your Name</label></b>

<BR>
<input type="text" class="form-control" name="name" id="name"  placeholder="Enter your Name" required /><br>

<BR>																		
<label for="email" ><b>Your Email</label></b>
							
<BR>							
<input type="text" class="form-control" name="email" id="email"  placeholder="Enter your Email" required />
<br>
								

<br>													
<label for="password"><b>Password</label>
</b>							
<br>									
<input type="password"  name="password" id="password"  placeholder="Enter your Password"  required />
	<br>							
<br>													
<label for="confirm"><b>Confirm Password</label></b>
							
<br>								
<input type="password" class="form-control" name="confirm_password" id="confirm"  placeholder="Confirm your Password"  required />
	<span id="message"></span>
	<br>							
<br>						

<input type="submit" class="b2" name="submit">
</form>
      


	
	<a href="biodata.php"><div class="biod">Enter YOUR Boidata</div></a>
	

	  

			
</body>

</html>
<?php
 include('dbcon.php');

if(isset($_POST['submit']))
{
	$nam = $_POST['name'];
	$mail = $_POST['email'];
	$pass1 = $_POST['password'];
	$pass2 = $_POST['confirm_password'];
	
	$qury="INSERT INTO `user_login`(`name`, `email`, `password`, `confirm_password`)
	VALUES ('$nam','$mail','$pass1','$pass2')";
	$result=mysqli_query($con,$qury);
	
	if($result == true)
	{
		?>
		<script>
		window.open('biodata.php');
		</script>
		<?php
	}
	
	
}


?>





